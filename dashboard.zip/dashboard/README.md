## React-D3-Dashboard

code source: https://github.com/sdq/react-d3-dashboard

This is a template project to build a dashboard with React + D3.